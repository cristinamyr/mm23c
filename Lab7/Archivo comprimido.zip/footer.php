<p><a href="http://es.wikipedia.org/wiki/Quiz" target="_blank">Que es un Quiz?</a></p>
<a href='https://github.com/cristinamyr/mm23c/tree/master/Lab7'>Link GITHUB</a>