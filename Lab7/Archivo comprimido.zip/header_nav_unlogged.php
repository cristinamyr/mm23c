
<header class='main' id='h1'>
	<span class="right"><a href="Registrar.php">Registrarse</a></span>
	<span class="right"><a href="Login.php">Login</a> <?php echo "Anónimo.";?></span>
	<h2>Quiz: el juego de las preguntas</h2>
</header>
<nav class='main' id='n1' role='navigation'>
	<span><a href='layout.php'>Inicio</a></spam>
	<span> <a href='jugar.php'> Jugar</a></span>
	<span><a href='creditos.php'>Creditos</a></spam>
</nav>
		